# Estacionamientos conceptuales para el video

`parking-layout.json` describe propuestas ilustrativas, no estacionamientos existentes documentados ni capacidades aprobadas.

| Parque | Plazas ilustrativas | Medida de plaza | Franja contigua libre |
|---|---:|---|---|
| P1 | 1 | 6.0 x 2.4 m | 3.6 m |
| P2 | 2 | 6.0 x 2.4 m | 3.6 m |
| P3 | 4 | 6.0 x 2.4 m | 3.6 m |
| P4 | 4 | 6.0 x 2.4 m | 3.6 m |
| P5 | 4 | 6.0 x 2.4 m | 3.6 m |

Se unieron las proyecciones triangulares de `Contexto_asphalt` de cada DAE con Shapely. Se sustrajeron las proyecciones de los demás objetos `Contexto_*` excepto demarcaciones blancas, y el contorno del parque documentado en `DATOS_DEL_MODELO.json`. Cada hilera y su franja vial contigua quedan completamente cubiertas por asfalto existente y sin intersección con las superficies excluidas. El JSON contiene coordenadas y métricas de esta comprobación.

Coordenadas Blender Z_UP: X = X del DAE; Y = -Z del DAE. La altura de asfalto es Z=0.005 m. El ángulo se mide en grados desde el eje X hacia Y; el eje longitudinal local corresponde a la hilera.

P1 solo permite una plaza en esta búsqueda; el candidato se encuentra cerca de una esquina del parque. No se validaron distancias a intersecciones, cruces peatonales, maniobras, entradas privadas, accesibilidad ni regulación vial. En todos los casos la ubicación y capacidad requieren revisión del plano vial. Debe mantenerse visible el rótulo **ESTACIONAMIENTO CONCEPTUAL** en el video.

La búsqueda reproducible usa `/workspace/proyectos-3d-env/venv/bin/python find_parking.py` y después `search_p1.py`. Los auxiliares y propuestas no modifican el repositorio ni sus modelos originales.
